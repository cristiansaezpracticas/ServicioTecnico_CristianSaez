<?php

namespace App\Entity;

use App\Repository\IncidenciaRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: IncidenciaRepository::class)]
class Incidencia
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 255)]
    private $titulo;

    #[ORM\Column(type: 'datetime')]
    private $fecha;

    #[ORM\Column(type: 'string', length: 255)]
    private $estado;
    
    
    #[ORM\ManyToOne(targetEntity: Cliente::class, inversedBy: 'incidencia')]
    #[ORM\JoinColumn(nullable: false)]
    private $cliente;

    #[ORM\ManyToOne(targetEntity: Usuario::class, inversedBy: 'incidencias')]
    #[ORM\JoinColumn(nullable: false)]
     private $usuario;   
    
         public function __construct()
    {
        $this->usuario = new ArrayCollection();
    }   
        
    

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitulo(): ?string
    {
        return $this->titulo;
    }

    public function setTitulo(string $titulo): self
    {
        $this->titulo = $titulo;

        return $this;
    }

    public function getFecha(): ?\DateTimeInterface
    {
        return $this->fecha;
    }

    public function setFecha(\DateTimeInterface $fecha): self
    {
        $this->fecha = $fecha;

        return $this;
    }

    public function getEstado(): ?string
    {
        return $this->estado;
    }

    public function setEstado(string $estado): self
    {
        $this->estado = $estado;

        return $this;
    }
    
         public function getCliente(): ?Cliente
     {
         return $this->cliente;
     }

     public function setCliente(?Cliente $cliente): self
     {
         $this->cliente = $cliente;

         return $this;
     }

     public function getUsuario(): ?Usuario
     {
         return $this->usuario;
     }

     public function setUsuario(?Usuario $usuario): self {
         $this->usuario = $usuario;
         
         return $this;
     }
     
}