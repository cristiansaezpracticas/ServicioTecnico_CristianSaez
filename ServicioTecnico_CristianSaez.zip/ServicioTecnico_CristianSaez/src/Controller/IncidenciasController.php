<?php

namespace App\Controller;

use App\Entity\Incidencia;
use App\Entity\Cliente;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Doctrine\Common\Collections\ArrayCollection;

class IncidenciasController extends AbstractController
{
    #[Route('/incidencias', name: 'app_incidencias')]
    public function index(): Response
    {
        return $this->render('incidencias/index.html.twig', [
            'controller_name' => 'IncidenciasController',
        ]);
    }
    
        /**
     * Inserta un post utilizando los formularios de symfony
     * @Route("/incidencias/insertar", name="insertar_incidencia")
     */
    public function insertar(Request $request, ManagerRegistry $doctrine): Response{
        $incidencia = new Incidencia();
        
        $form = $this->createFormBuilder($incidencia)
                ->add('titulo', TextType::class)
                ->add('estado',ChoiceType::class, [
                        'choices'  => [ 
                        'Iniciada' => "Iniciada",
                        'En proceso' => "En proceso",
                        'Resuelta' => "Resuelta",
                    ],
                    'attr' => array(
                    'class' => 'controls'
                )
                ] )
                ->add('Cliente',EntityType::class, [
                       'class' => Cliente::class,
                    'choice_label' => 'nombre',
                    'choice_value' => 'id',
                    'attr' => array(
                    'class' => 'controls'
                )
                ])
                ->add('Insertar', SubmitType::class)
                ->getForm();
        
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $cliente = $form->getData();
            $incidencia->setFecha(new \Datetime());
            $cliente = $form->get('Cliente')->getData();
            $incidencia->setCliente($cliente);
            $incidencia->setUsuario($this->getUser());
            $em = $doctrine->getManager();
            $em->persist($incidencia);
            $em->flush();
            return $this->redirectToRoute("app_incidencias");
        }
        return $this->renderForm('incidencias/insertar.html.twig', ['form_post'=>$form]);
    }
    
    /**
     * @Route("/incidencias/listado", name="listado_incidencias")
     */
    public function listado(ManagerRegistry $doctrine): Response {
        $repositorio = $doctrine->getRepository(Incidencia::class);
        $incidencias = $repositorio->findAll();

        return $this->render('incidencias/listado.html.twig', [
                    'incidencias' => $incidencias,
        ]);
    }
    
    /**
     * 
     * @Route("/incidencias/borrar/{id<\d+>}", name="borrar_incidencia")
     */
    public function borrar(Incidencia $incidencia, ManagerRegistry $doctrine): Response {
        $em = $doctrine->getManager();
        $em->remove($incidencia);
        $em->flush();

        $this->addFlash("aviso", "Mensaje borrado");
        return $this->redirectToRoute("app_incidencias");
    }
    
    /**
     * @Route("/incidencias/editar/{id}", name="editar_incidencia")
     */
    public function editar(Incidencia $incidencia, Request $request, ManagerRegistry $doctrine): Response {
        if ($request->isMethod('POST')) {

            $titulo = $request->request->get('titulo');
            $estado = $request->request->get('estado');

            $incidencia->setTitulo($titulo);
            $incidencia->setEstado($estado);

            if (empty($titulo) || empty($estado)) {
                $this->addFlash('aviso', "Debe completar tanto el título como el texto");
                return $this->render("incidencias/editar.html.twig", ['incidencia' => $incidencia]);
            } else {
                $em = $doctrine->getManager();
                $em->flush();

                $this->addFlash('aviso', "Incidencia editado");
                return $this->redirectToRoute("app_incidencias");
            }
            
        } else {

            return $this->render("incidencias/editar.html.twig", ['incidencia' => $incidencia]);
        }
    }
    
    /**
     * @Route("/incidencias/{id<\d+>}",name="ver_incidencia")
    */
    public function ver(Incidencia $incidencia, Request $request, ManagerRegistry $doctrine): Response {
        
        $repositorio = $doctrine->getRepository(Incidencia::class);
        $id = $request->get('id');
        $incidencia = $repositorio->find($id);
        
        return $this->render('incidencias/ver.html.twig', ['incidencia' => $incidencia]);
            
    }
}