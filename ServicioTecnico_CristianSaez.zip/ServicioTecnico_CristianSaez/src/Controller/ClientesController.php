<?php

namespace App\Controller;

use App\Entity\Cliente;
use App\Entity\Incidencia;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Validator\Constraints\NotBlank;

class ClientesController extends AbstractController
{
    #[Route('/clientes', name: 'app_clientes')]
    public function index(): Response
    {
        return $this->render('clientes/index.html.twig', [
            'controller_name' => 'ClientesController',
        ]);
    }
    
    /**
     * @Route("/clientes/listado", name="listado_clientes")
     */
    public function listado(ManagerRegistry $doctrine): Response {
        $repositorio = $doctrine->getRepository(Cliente::class);
        $clientes = $repositorio->findAll();

        return $this->render('clientes/listado.html.twig', [
                    'clientes' => $clientes,
        ]);
    }
    
    /**
     * Inserta un post utilizando los formularios de symfony
     * @Route("/clientes/insertar", name="insertar_cliente")
     */
    public function insertar(Request $request, ManagerRegistry $doctrine): Response{
        $cliente = new Cliente();
        
        $form = $this->createFormBuilder($cliente)
                ->add('nombre', TextType::class)
                ->add('apellidos', TextType::class)
                ->add('telefono', TextType::class)
                ->add('direccion', TextType::class)
                ->add('Insertar', SubmitType::class)
                ->getForm();
        
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $cliente = $form->getData();
            $em = $doctrine->getManager();
            $em->persist($cliente);
            $em->flush();
            return $this->redirectToRoute("app_clientes");
        }
        return $this->renderForm('clientes/insertar.html.twig', ['form_post'=>$form]);
    }
    
    /**
     * @Route("/clientes/{id<\d+>}",name="ver_cliente")
    */
    public function ver(Cliente $cliente, Request $request, ManagerRegistry $doctrine): Response {
        
        $incidencias = new Incidencia();
        $repositorio = $doctrine->getRepository(Cliente::class);
        $repositorio2 = $doctrine->getRepository(\App\Entity\Incidencia::class);
        $id = $request->get('id');
        $cliente = $repositorio->find($id);
        $incidencias = $repositorio2->findByIdCliente($id);
        
        return $this->render('clientes/ver.html.twig', ['cliente' => $cliente ,'incidencias' => $incidencias]);
            
    }
    
    /**
     * 
     * @Route("/clientes/borrar/{id<\d+>}", name="borrar_cliente")
     */
    public function borrar(Cliente $cliente, ManagerRegistry $doctrine): Response {
        $em = $doctrine->getManager();
        $em->remove($cliente);
        $em->flush();

        $this->addFlash("aviso", "Mensaje borrado");
        return $this->redirectToRoute("app_clientes");
    }
    
    /**
     * @Route("/clientes/editar/{id}", name="editar_cliente")
     */
    public function editar(Cliente $cliente, Request $request, ManagerRegistry $doctrine): Response {
        if ($request->isMethod('POST')) {

            $nombre = $request->request->get('nombre');
            $apellidos = $request->request->get('apellidos');
            $telefono = $request->request->get('telefono');
            $direccion = $request->request->get('direccion');

            $cliente->setNombre($nombre);
            $cliente->setApellidos($apellidos);
            $cliente->setTelefono($telefono);
            $cliente->setDireccion($direccion);

            if (empty($nombre) || empty($telefono)) {
                $this->addFlash('aviso', "Debe completar tanto el título como el texto");
                return $this->render("clientes/editar.html.twig", ['cliente' => $cliente]);
            } else {
                $em = $doctrine->getManager();
                $em->flush();

                $this->addFlash('aviso', "Cliente editado");
                return $this->redirectToRoute("app_clientes");
            }
            
        } else {

            return $this->render("clientes/editar.html.twig", ['cliente' => $cliente]);
        }
    }
    
        /**
            * @Route("/incidencias/editarincidenciacliente/{id<\d+>}", name="editar_incidencia_cliente")
            */
        public function editarincidenciacliente(Incidencia $incidencia, Request $request, ManagerRegistry $doctrine): Response{
             if($this->getUser() === null){
                    return $this->redirectToRoute("login");
                }
                
            $securityContext = $this->container->get('security.authorization_checker');
            if ($securityContext->isGranted('IS_REMEMBERED')) {
                $this->addFlash("aviso", "Debe de volver a iniciar sesión para editar una incidencia.");
                return $this->redirectToRoute('app_incidencia');
            }
            
            //FORMULARIO
            //$incidencia = new Incidencia();
            $form = $this->createFormBuilder($incidencia)
                ->add('Titulo', TextType::class, [
                'constraints' => [
                    new NotBlank([
                        'message' => 'Por favor, indique el titulo de la incidencia.',
                    ]),
                ],
                'data' => $incidencia->getTitulo(),
                'attr' => array(
                    'placeholder' => 'Ingrese el Titulo ',
                    'class' => 'controls'
                )
            ])
                ->add('Estado',ChoiceType::class, [
                        'choices'  => [ 
                        $incidencia->getEstado() => $incidencia->getEstado(),
                        'Iniciada' => "Iniciada",
                        'En proceso' => "En proceso",
                        'Resuelta' => "Resuelta",
                    ],
                    'attr' => array(
                    'class' => 'controls'
                )
                ] )
                ->add('submit', SubmitType::class, array(
                    'label' => 'Modificar Incidencia',
                    'attr'  => array('class' => 'botons')
                ))
                ->getForm();
                ;
                $form->handleRequest($request);
            if($form->isSubmitted() && $form->isValid()){
                $titulo = $form->get('Titulo')->getData();
                $estado = $form->get('Estado')->getData();
            
                $incidencia->setTitulo($titulo);
                $incidencia->setEstado($estado);
                $incidencia->setCliente($incidencia->getCliente());
                $incidencia->setUsuario($incidencia->getUsuario());
                $incidencia->setFecha($incidencia->getFecha());
                $em = $doctrine->getManager();
                $em->flush();

                $this->addFlash("aviso", "Incidencia editada");
            return $this->redirectToRoute("app_clientes");
            }
            return $this->renderForm('clientes/editarincidencia.html.twig', ['form_post'=>$form]);
            }
    
    /**
     * @Route("/incidencias/insertarincidenciacliente/{id<\d+>}", name="insertar_incidencia_cliente")
    */
    public function insertarincidenciacliente(Cliente $cliente,Request $request, ManagerRegistry $doctrine): Response {
        if($this->getUser() === null){
            return $this->redirectToRoute("login");
        }
            $incidencia = new Incidencia();
            $form = $this->createFormBuilder($incidencia)
                ->add('Titulo', TextType::class, [
                'constraints' => [
                    new NotBlank([
                        'message' => 'Por favor, indique el titulo de la incidencia.',
                    ]),
                ],
                'attr' => array(
                    'placeholder' => 'Ingrese el Titulo ',
                    'class' => 'controls'
                )
            ])
                ->add('Estado',ChoiceType::class, [
                        'choices'  => [ 
                        'Iniciada' => "Iniciada",
                        'En proceso' => "En proceso",
                        'Resuelta' => "Resuelta",
                    ],
                    'attr' => array(
                    'class' => 'controls'
                )
                ] )
                ->add('submit', SubmitType::class, array(
                    'label' => 'Insertar Incidencia',
                    'attr'  => array('class' => 'botons')
                ))
                ->getForm();
                ;
                $form->handleRequest($request);
            if($form->isSubmitted() && $form->isValid()){
                $titulo = $form->get('Titulo')->getData();
                $estado = $form->get('Estado')->getData();
            
                $incidencia->setTitulo($titulo);
                $incidencia->setEstado($estado);
                $incidencia->setCliente($cliente);
                $incidencia->setUsuario($this->getUser());
                $incidencia->setFecha(new \DateTime());
                $em = $doctrine->getManager();
                $em->persist($incidencia);
                $em->flush();
            
            $this->addFlash("aviso", "Incidencia Insertada");
            return $this->redirectToRoute("app_clientes");
        } else {
            return $this->renderForm("clientes/insertarincidenciacliente.html.twig", ['form_post' => $form]);
        }
    }
    
}
